import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class Starter {
	public static void main(String args[]){
		new Listener();
	}
}
