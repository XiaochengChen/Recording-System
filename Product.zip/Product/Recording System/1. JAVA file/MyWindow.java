import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class MyWindow extends JDialog{
	MyDoor w=new MyDoor();
	JPanel panel=new JPanel();
	JPanel panel1=new JPanel();
	JButton b4=new JButton("Goods");
	JButton b5=new JButton("Salesperson");
	JButton b6=new JButton("Goods");
	JButton b7=new JButton("Salesperson");

	public MyWindow(){
		setSize(640,480);
		setLocation(100,100);
	}

	public void add1(){//two buttons after clicking input
		Container c1=getContentPane();
		c1.removeAll();
		panel.setLayout(null);
		panel.add(b4);
		panel.add(b5);
		b4.setBounds(240,100,160,60);
		b5.setBounds(240,250,160,60);
		c1.add(panel);
		setTitle("input");

		b4.addActionListener(new ActionListener(){//Goods
			public void actionPerformed(ActionEvent e){
				w.add4();
				w.setVisible(true);
			}
		});

		b5.addActionListener(new ActionListener(){//Salesperson
			public void actionPerformed(ActionEvent e){
				w.add5();
				w.setVisible(true);
			}
		});
	}

	public void addwhat(){
		w.add2();
		w.setVisible(true);
	}

	public void add3(){//two buttons after clicking reports
		Container c2=getContentPane();
		c2.removeAll();
		panel1.setLayout(null);
		panel1.add(b6);
		panel1.add(b7);
		b6.setBounds(240,100,160,60);
		b7.setBounds(240,250,160,60);
		c2.add(panel1);
		setTitle("reports");
		b6.addActionListener(new ActionListener(){//Goods
			public void actionPerformed(ActionEvent e){
				w.add6();
				w.setVisible(true);
			}
		});

		b7.addActionListener(new ActionListener(){//Salesperson
			public void actionPerformed(ActionEvent e){
				w.add7();
				w.setVisible(true);
			}
		});
	}
}