public class Ranks
{
	private String name;
	private int quantityS;
	private double revenue;
	private double profit;
	private double tCost;

	public Ranks()
	{
		name=null;
		quantityS=-1;
		revenue=0.0;
		profit=0.0;
		tCost=0.0;
	}

	public Ranks(String aName,int aQuantity,double aRevenue,double aProfit,double aTcost)
	{
		name=aName;
		quantityS=aQuantity;
		revenue=aRevenue;
		profit=aProfit;
		tCost=aTcost;
	}

	public void setName(String aName)
	{
		name=aName;
	}
	public void setQuantityS(int aQuantity)
	{
		quantityS=aQuantity;
	}
	public void setRevenue(double aRevenue){
		revenue=aRevenue;
	}
	public String getName()
	{
		return name;
	}
	public int getQuantityS()
	{
		return quantityS;
	}
	public double getRevenue()
	{
		return revenue;
	}
	public double getProfit()
	{
		return profit;
	}
	public double getCost()
	{
		return tCost;
	}
}





