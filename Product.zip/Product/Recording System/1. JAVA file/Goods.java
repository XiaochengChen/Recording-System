public class Goods
{
	private String name;
	private double price;
	private double cost;
	private int quantity;
	private int initialQ;
	private double money;
	private double profit;
	private double tCost;

	public Goods(String aName,double aPrice, double aCost, int aQuantity)
	{
		name=aName;
		price=aPrice;
		cost=aCost;
		quantity=aQuantity;
		initialQ=aQuantity;
		money=0;
		profit=0;
		tCost=0;
	}

	public Goods(String aName,double aPrice,double aCost, int aQuantity,int aInitialQ)
	{
		name=aName;
		price=aPrice;
		cost=aCost;
		quantity=aQuantity;
		initialQ=aInitialQ;
		money=(price-cost)*(initialQ-quantity);
		profit=price*(initialQ-quantity);
		tCost=cost*(initialQ-quantity);
	}

	public void setName(String aName)
	{
		name=aName;
	}
	public void setPrice(double aPrice)
	{
		price=aPrice;
	}
	public void setCost(double aCost)
	{
		cost=aCost;
	}
	public void setQuantity(int aQuantity)
	{
		quantity=aQuantity;
	}
	public String getName()
	{
		return name;
	}
	public double getPrice()
	{
		return price;
	}
	public double getCost()
	{
		return cost;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public int getInitialQ()
	{
		return initialQ;
	}
	public double getMoney()
	{
		return money;
	}
	public double getProfit()
	{
		return profit;
	}
	public double getTcost()
	{
		return tCost;
	}
}





