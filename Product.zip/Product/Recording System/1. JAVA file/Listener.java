import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
class Listener extends JFrame{
	private JButton b1,b2,b3;
	MyWindow f=new MyWindow();

	public Listener(){
		setTitle("Recording System");
		setSize(640,480);
		setLayout(null);

		b1=new JButton("input");
		b2=new JButton("transaction");
		b3=new JButton("reports");

		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				f.add1();
				f.setVisible(true);
			}
		});

		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				f.addwhat();
				f.setVisible(false);
			}
		});

		b3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				f.add3();
				f.setVisible(true);
			}
		});

		b1.setBounds(240,30,160,60);
		b2.setBounds(240,160,160,60);
		b3.setBounds(240,290,160,60);
		add(b1);
	    add(b2);
	    add(b3);
	    setVisible(true);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}