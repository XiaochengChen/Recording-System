public class SalesPerson
{
	private String name;
	private double sales;

	public SalesPerson()
	{
		name=null;
		sales=-1;
	}

	public SalesPerson(String aName, double aSales){
		name=aName;
		sales=aSales;
	}

	public void setName(String aName)
	{
		name=aName;
	}
	public void setSales(double aSales)
	{
		sales=aSales;
	}
	public String getName()
	{
		return name;
	}
	public double getSales()
	{
		return sales;
	}
}