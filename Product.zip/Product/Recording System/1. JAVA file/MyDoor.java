import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class MyDoor extends JDialog{
	Store x=new Store();
	JPanel panel1=new JPanel();
	JPanel panel2=new JPanel();
	JPanel panel3=new JPanel();
	JPanel panel4=new JPanel();
	JLabel label=new JLabel("Goods name");
	JTextField text=new JTextField(120);
	JLabel label2=new JLabel("Price");
	JTextField text2=new JTextField(120);
	JLabel label3=new JLabel("Cost");
	JTextField text3=new JTextField(120);
	JLabel label4=new JLabel("Quantity");
	JTextField text4=new JTextField(120);
	JLabel label5=new JLabel("Name");
	JTextField text5=new JTextField(120);
	JLabel label6=new JLabel("Sales");
	JTextField text6=new JTextField(120);
	JButton save2=new JButton("Save");
	JButton save3=new JButton("Save");
	JButton add1=new JButton("Add");
	JButton add2=new JButton("Add");
	JButton add3=new JButton("Process");
	JLabel label7=new JLabel("goods name");
	JTextField text7=new JTextField(120);
	JLabel label8=new JLabel("quantity");
	JTextField text8=new JTextField(120);
	JLabel label9=new JLabel("salesperson");
	JTextField text9=new JTextField(120);
	JButton save1=new JButton("Save");
	JButton d1=new JButton("Delete");
	JButton d2=new JButton("Delete");

	public MyDoor(){
		super();
		setSize(640,480);
		setLocation(150,150);

	}

	public void add2(){//3 textfields after clicking transaction
		Container c1=getContentPane();
		c1.removeAll();
		panel1.setLayout(null);
		panel1.add(label7);
		panel1.add(text7);
		panel1.add(label8);
		panel1.add(text8);
		panel1.add(label9);
		panel1.add(text9);
		panel1.add(save1);
		panel1.add(add3);
		label7.setBounds(40,120,70,30);
		text7.setBounds(110,120,100,30);
		label8.setBounds(220,120,70,30);
		text8.setBounds(290,120,100,30);
		label9.setBounds(400,120,80,30);
		text9.setBounds(480,120,100,30);
		add3.setBounds(140,300,160,60);
		save1.setBounds(340,300,160,60);
		c1.add(panel1);
		setTitle("Transaction");

		add3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String name=text7.getText();
				int quantity=Integer.parseInt(text8.getText());
				String sName=text9.getText();
				if(x.process(name,quantity,sName)==true){
					text7.setText("");
					text8.setText("");
					text9.setText("");
				}
				else{
					text7.setText("No Goods or");//cannot find this Goods in the hash table
					text8.setText("Sold out or");//Goods'quantity equals or below 0
					text9.setText("No Salesperson");// cannot find this salesoerson in the record
				}
			}
		});

		save1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				x.writeTable();
				x.writeSalesperson();
			}
		});
	}


	public void add4(){//4 textfields after clicking goods, still have errors!
		Container c2=getContentPane();
		c2.removeAll();
		panel2.setLayout(null);
		panel2.add(label);
		panel2.add(text);
		panel2.add(label2);
		panel2.add(text2);
		panel2.add(label3);
		panel2.add(text3);
		panel2.add(label4);
		panel2.add(text4);
		panel2.add(save2);
		panel2.add(add1);
		panel2.add(d1);
		label.setBounds(45,80,100,30);
		text.setBounds(145,80,150,30);
		label2.setBounds(345,80,100,30);
		text2.setBounds(445,80,150,30);
		label3.setBounds(45,180,100,30);
		text3.setBounds(145,180,150,30);
		label4.setBounds(345,180,100,30);
		text4.setBounds(445,180,150,30);
		save2.setBounds(440,300,160,60);
		add1.setBounds(40,300,160,60);
		d1.setBounds(240,300,160,60);
		c2.add(panel2);
		setTitle("Goods input");

		add1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String name=text.getText();
				double price=Double.parseDouble(text2.getText());
				double cost=Double.parseDouble(text3.getText());
				int quantity=Integer.parseInt(text4.getText());
				if(x.add(name,price,cost,quantity)==true){//successfully add
					text.setText("");
					text2.setText("");
					text3.setText("");
					text4.setText("");
				}
				else{
					text.setText("");
					text2.setText("error");
					text3.setText("error");
					text4.setText("");
				}
			}
		});

		save2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				x.writeTable();
			}
		});

		d1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String name=text.getText();
				if(x.delete(name)==true)//successfully delete
					text.setText("");
				else
					text.setText("No goods!");
					text.setText("");
			}
		});
	}

	public void add5(){//2 textfilds after clicking salesperson
		Container c3=getContentPane();
		c3.removeAll();
		panel3.setLayout(null);
		panel3.add(label5);
		panel3.add(text5);
		panel3.add(label6);
		panel3.add(text6);
		panel3.add(save3);
		panel3.add(add2);
		panel3.add(d2);
		label5.setBounds(80,80,50,30);
		text5.setBounds(190,80,150,30);
		label6.setBounds(80,180,50,30);
		text6.setBounds(190,180,150,30);
		add2.setBounds(40,300,160,60);
		save3.setBounds(440,300,160,60);
		d2.setBounds(240,300,160,60);
		c3.add(panel3);
		setTitle("Salesperson input");

		add2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String name=text5.getText();
				double sales=Double.parseDouble(text6.getText());
				if(x.input(name,sales)==true){
					text5.setText("");
					text6.setText("");
				}
				else{
					text5.setText("Error!");
				}
			}
		});

		save3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				x.writeSalesperson();
			}
		});
		d2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String name=text5.getText();
				if(x.delete2(name)==true)
					text5.setText("");
				else
					text5.setText("No Person!");
					text5.setText("");
			}
		});

	}

	public void add6(){//goods report generated after clicking goods in the report part
		Container c=getContentPane();
		c.removeAll();
		x.readTable();
		x.selectionSort();
		JTextArea ta=new JTextArea(x.toString());
		ta.setFont(new java.awt.Font("Dialog",1,15));
		ta.setForeground(Color.pink);
		ta.setEditable(false);
		JScrollPane sp=new JScrollPane(ta);
		c.add(sp);
		ta.setBackground(Color.black);
		setTitle("Goods Report");
	}

	public void add7(){//salesperson report generated after clicking salesperson in the report part
		Container c4=getContentPane();
		c4.removeAll();
		panel4.setLayout(null);
		x.readSalesperson();
		x.selectionSort2();
		x.update();
		JTextArea ta=new JTextArea(x.toString2());
		ta.setFont(new java.awt.Font("Dialog",1,15));
		ta.setForeground(Color.pink);
		ta.setEditable(false);
		JScrollPane sp=new JScrollPane(ta);
		c4.add(sp);
		ta.setBackground(Color.black);
		setTitle("Sales Report");
	}
}