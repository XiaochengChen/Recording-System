import java.io.*;

public class Store{
	private Goods[]table;
	private Ranks[]rank;
	private Goods NEVER_USED= new Goods("never",-1,-1,-1);
	private Ranks NEVER= new Ranks("never",-1,0,0,0);
	private SalesPerson[]record;
	private SalesPerson NULL= new SalesPerson("NULL",-1);
	private double average;
	private double highest;
	private static final int COUNT=100;
	private static final int PERSON=5;

	public Store(){
		rank=new Ranks[COUNT];//not full can use rank.length()
		table=new Goods[COUNT];
		for(int count=0;count<table.length;count++){
			table[count]=NEVER_USED;
			rank[count]=NEVER;
		}
		record=new SalesPerson[PERSON];
		for(int count=0;count<record.length;count++){
			record[count]=NULL;
		}
		average=0;
		highest=0;
	}

	public boolean process(String goodsName,int quantity,String salesName){
		int i=search(goodsName);
		if(i==-1){
			return false;
		}
		else{
			int newQuantity=table[i].getQuantity()-quantity;
			if(newQuantity<=0){
				return false;
			}
			else{
				table[i].setQuantity(newQuantity);
				double price=table[i].getPrice();
				double salesGain=price*quantity;
				int j=findPerson(salesName);
				if(j==-1){
					return false;
				}
				else{
					double newSales=record[j].getSales()+salesGain;
					record[j].setSales(newSales);
					return true;
				}
			}
		}
	}

	private int getLoc(String name)
	{
		int loc=hashFunction(name);
		if(!table[loc].getName().equals("never")){
			for(int count=0;count<table.length;count++){
				if(table[(loc+probe(count))%COUNT].getName().equals("never")){
					return(loc+probe(count))%COUNT;
				}
			}
		}
		else{
			return loc;
		}
		return -1;
	}

	private int hashFunction(String name){
		int sum=0;
		for(int count=0;count<name.length();count++){
			char character=name.charAt(count);
			//System.out.println(character);
			int ascii=(int)character;
			//System.out.println(ascii);
			sum=sum+ascii;
			//System.out.println(sum);
		}
		return sum%COUNT;
	}

	private int probe(int attempt){
		int rtn=(int)(Math.pow((double)attempt,2.0));//attempt's power of 2. This is the quadratic probbing.
		return rtn;
	}

	private int search(String name) {
		int loc = hashFunction(name);
		int prb;
		for (int count=0;count< table.length;count++) {
			prb = probe(count);
			if (table[(loc+prb) % table.length].getName().equals(name))
				return (loc+prb) % table.length;
			if (table[(loc+prb) % table.length].getName().equals("never"))
				return -1;
		}
		return -1;
	}

	public boolean add(String name,double price,double cost,int quantity) {
		if(cost>=price)
			return false;
		else{
			int i=search(name);
			if(i!=-1)
				table[i]=new Goods(name,price,cost,quantity);
			else{
				int loc = getLoc(name);
				if (loc==-1)
					return false;
				else{
					table[loc] =new Goods(name,price,cost,quantity);
					return true;
				}
			}
			return true;
		}
	}

	public boolean delete(String name) {
		int loc = search(name);//find the goods
		if (loc != -1) {
			table[loc] = NEVER_USED;
			for(int count=0;count<rank.length;count++){
				if(rank[count].getName().equals(name))
					rank[count]=NEVER;
			}
			return true;
		}
		return false;
	}

	public void writeTable(){
		try{
			RandomAccessFile f=new RandomAccessFile("Goods record.dat","rw");
			for(int count=0; count<table.length;count++){
				String name=table[count].getName();
				if(name.length()>18)
					name=name.substring(0,18);
				f.seek(44*count);
				f.writeUTF(name);
				double price=table[count].getPrice();
				f.seek(44*count+20);
				f.writeDouble(price);
				double cost=table[count].getCost();
				f.seek(44*count+28);
				f.writeDouble(cost);
				int quantity=table[count].getQuantity();
				f.seek(44*count+36);
				f.writeInt(quantity);
				int Initial=table[count].getInitialQ();
				f.seek(44*count+40);
				f.writeInt(Initial);
			}
			f.close();
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void readTable(){//read Goods into GoodsArray Rank
		try{
			String goodsName=null;
			double price=0.0;
			double cost=0.0;
			int quantity=0;
			int quantitySaled=0;
			int Initial=0;
			double revenue=0.0;
			double profit=0;
			double tCost=0;
			RandomAccessFile f=new RandomAccessFile("Goods record.dat","r");
			int i=0;
			int j=0;
			for(int count=0;count<table.length;count++){
				f.seek(44*count);
				goodsName=f.readUTF();
				//System.out.print(goodsName);
				f.seek(44*count+20);
				price=f.readDouble();
				f.seek(44*count+28);
				cost=f.readDouble();
				f.seek(44*count+36);
				quantity=f.readInt();
				f.seek(44*count+40);
				Initial=f.readInt();
				table[count]=new Goods(goodsName,price,cost,quantity,Initial);

				if(!goodsName.equals("never")){
					j=search(goodsName);
					//System.out.println(goodsName);
					//System.out.println(j);(okay)
					quantitySaled=table[j].getInitialQ()-quantity;
					//System.out.println(table[j].getInitialQ());
					revenue=table[j].getMoney();
					profit=table[j].getProfit();
					tCost=table[j].getTcost();
					//System.out.print(revenue);
					rank[i]=new Ranks(goodsName,quantitySaled,revenue,profit,tCost);
					i++;
				}

			}
			f.close();
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}
	}

	public void selectionSort(){//select goods
		for(int count=0;count<rank.length-1;count++){
			int max=count;
			for(int b=count+1;b<rank.length;b++){
				if(rank[b].getRevenue()>rank[max].getRevenue())
					max=b;
			}
			Ranks temp=rank[count];
			rank[count]=rank[max];
			rank[max]=temp;
		}
	}

	public String toString() {
		double profit=0;
		double cost=0;
		double revenue=0;
		for(int count=0;count<rank.length;count++){
			revenue=revenue+rank[count].getRevenue();
			profit=profit+rank[count].getProfit();
			cost=cost+rank[count].getCost();
		}
		String rtn = "";
		rtn+="Total Profit:  "+profit+"    ";
		rtn+="Total Cost:  "+cost+"    ";
		rtn+="Total Revenue:  "+revenue+"\n";
		rtn+="Ranking   "+"Goods Name   "+"Quantity Saled   "+"Revenue"+"\n";
		for(int count=0;count<rank.length; count++) {
			rtn +=count +1+"                 ";
			//rtn += rank[count].getQuantityS()+"\n";
			rtn += rank[count].getName()+"                       ";
			rtn += rank[count].getQuantityS()+"                   ";
			rtn += rank[count].getRevenue()+"\n";
		}
		return rtn;
	}


	public boolean input(String name, double sales){
		for(int a=0;a<PERSON;a++){
			if(record[a].getName().equals("NULL")){
				record[a]=new SalesPerson(name,sales);
				return true;
			}
		}
		return false;
	}

	public boolean delete2(String name){
		int i=findPerson(name);
		if(i!=-1){
			record[i]=NULL;
			return true;
		}
		return false;
	}

	private int findPerson(String name){//sequential search
		int count=0;
		while(count<PERSON){
			if(record[count].getName().equals(name))
				return count;
			count=count+1;
		}
		return -1;
	}

	public void update(){
		double sum=0;
		for(int i=0;i<record.length;i++){
			sum=sum+record[i].getSales();
			if(record[i].getSales()>highest)
				highest=record[i].getSales();
		}
		average=sum/record.length;
	}

	public void selectionSort2(){//sort salesperson
		for(int i=0;i<record.length-1;i++){
			int max=i;
			for(int j=i+1;j<PERSON;j++){
				if(record[j].getSales()>record[max].getSales())
					max=j;
			}
			SalesPerson temp=record[i];
			record[i]=record[max];
			record[max]=temp;
		}
	}

	public void writeSalesperson()
	{
		try{
			RandomAccessFile f=new RandomAccessFile("Sales Record.dat","rw");
			for(int i=0;i<PERSON;i++){
				String name=record[i].getName();
				if(name.length()>24)
					name=name.substring(0,24);
				f.seek(34*i);
				f.writeUTF(name);
				double sales=record[i].getSales();
				f.seek(34*i+26);
				f.writeDouble(sales);
			}
			f.close();
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void readSalesperson(){
		try{
			String name=null;
			double sales=0.0;
			RandomAccessFile f=new RandomAccessFile("Sales Record.dat","r");
			long records=f.length()/34;
			for(int i=0;i<records;i++){
				f.seek(34*i);
				name=f.readUTF();
				f.seek(34*i+26);
				sales=f.readDouble();
				record[i]=new SalesPerson(name,sales);
			}
			f.close();
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}

	public String toString2(){
		String rtn="";
		rtn+="Highest sale: "+highest+"    Average sale: "+average+"\n";
		rtn+="Name        "+"Sales"+"\n";
		for(int count=0;count<PERSON;count++){
			rtn+=record[count].getName()+"         ";
			rtn+=record[count].getSales()+"\n";
		}
		return rtn;
	}
}